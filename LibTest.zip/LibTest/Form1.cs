﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SwissPostAddressReader;
namespace LibTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        AddressReader reader = new AddressReader();


        private async void Read()
        {
            await reader.ReadCsv("J:\\p.csv");

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Thread t = new Thread(Read);
            t.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<PostCanton> cantons = reader.GetCantons();

            foreach(var canton in cantons)
            {
                if(canton.CantonAbbrevation == textBox1.Text)
                {
                    MessageBox.Show("Found Canton " + canton.CantonAbbrevation);
                    return;
                }

                foreach(var city in canton.Cities)
                {
                    if(city.Name == textBox1.Text)
                    {
                        MessageBox.Show("Found City " + city.Name);
                        return;
                    }

                    foreach(var street in city.Streets)
                    {
                        if(street.Name == textBox1.Text)
                        {
                            MessageBox.Show("Found " + street.Name + " in city " + city.Name);
                        }

                        foreach(var house in street.Houses.ToList())
                        {
                            int nbr;
                            int.TryParse(textBox1.Text, out nbr);
                            if (nbr == 0) return;
                            if (house.HouseNumber == nbr)
                            {
                                MessageBox.Show("Found House number " + house.HouseNumber + " in street " + street.Name + " in city " + city.Name + " which is in canton " + canton.CantonAbbrevation);

                            }
                        }
                    }
                }
            }
        }
    }
}
