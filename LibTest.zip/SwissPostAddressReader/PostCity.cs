﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwissPostAddressReader
{
    public class PostCity
    {
        public long ONRP { get; set; }
        public int PostalCode { get; set; }
        public List<PostStreet> Streets { get; set; }
        public string Name { get; set; }

        public PostCity()
        {
            Streets = new List<PostStreet>();
        }
    }
}
