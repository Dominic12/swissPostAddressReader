﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwissPostAddressReader
{
   public class PostCanton
    {
        public List<PostCity> Cities { get; set; }
        public string CantonAbbrevation { get; set; }
    }
}
