﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.VisualBasic.FileIO;
namespace SwissPostAddressReader
{
    public class AddressReader
    {
        private static AddressReader _addressReader;
        private PostSwiss _postSwiss = new PostSwiss();
        private List<PostCanton> _postCantons = new List<PostCanton>();
        private Stream _memoryStream = new MemoryStream();

        public AddressReader()
        {

        }

    
        private async Task test()
        {
            Enumerable
                .Range(1, Environment.ProcessorCount) // replace with lesser number if 100% usage is not what you are after.
                .AsParallel()
                .Select(i => {
                     var end = DateTime.Now + TimeSpan.FromSeconds(10);
                        while (DateTime.Now < end)
                         /*nothing here */
                                        ;
                         return i;
                        })
                    .ToList(); // ToList makes the query execute.
                }



        public static AddressReader GetInstance()
        {
            //Singleton ?
            if (_addressReader == null) _addressReader = new AddressReader();
            return _addressReader;
        }

        public async Task<PostCanton> ReadHouses()
        {
            return null;
        }
        public async Task<bool> ReadCsv(String filePath)
        {

            
            if (File.Exists(filePath))
            {
                Console.WriteLine("Starting Reading CSV File..");
                String input = File.ReadAllText(filePath);
                var bytes = Encoding.ASCII.GetBytes(input);
                using (var stream = _memoryStream)
                {
                    stream.Write(bytes, 0, bytes.Length);
                    stream.Seek(0, SeekOrigin.Begin);
                    await readData();
                    return true;
                }
            }
            return false;

        }

        public async Task readData()
        {

            using (TextFieldParser csvParser = new TextFieldParser(_memoryStream))
            {
                csvParser.SetDelimiters(new string[] { ";" });
                csvParser.HasFieldsEnclosedInQuotes = true;
                csvParser.CommentTokens = new string[] { "#" };

                csvParser.ReadLine();
                bool printed = false;

                IEnumerable<PostStreet> streets = null;


                while (!csvParser.EndOfData)
                {
                    string[] fields = csvParser.ReadFields();
                    //check field lenght
                    int housecount = 0;
                    if (fields[0].Equals("01"))
                    {

                        if (fields.Length >= 15)
                        {
                            // Console.WriteLine("Vertified Entry as Entity Type NEW_PLZ1");
                        }
                        else
                        {
                            //Console.WriteLine("Couldn't vertify Entry of Type NEW_PLZ1");
                            continue;
                        }

                        //Setup new City Object

                        var city = new PostCity();

                        //Get ONRP

                        city.ONRP = long.Parse(fields[1]);


                        //Get PLZ

                        city.PostalCode = int.Parse(fields[4]);
                        //Get Name

                        city.Name = fields[7];


                        //Get Canton

                        string cantonAbbrevation = fields[9];

                        //Tricky Part, need to lookup the canton in our list and when not found, create a new one and insert our object

                        if (_postCantons.Where(canton => canton.CantonAbbrevation == cantonAbbrevation).FirstOrDefault() != null)
                        {
                            foreach (var canton in _postCantons)
                            {
                                if (canton.CantonAbbrevation == cantonAbbrevation)
                                {
                                    canton.Cities.Add(city);
                                    break;

                                }
                            }
                        }
                        else
                        {
                            var canton = new PostCanton();
                            canton.CantonAbbrevation = cantonAbbrevation;
                            canton.Cities = new List<PostCity>();
                            canton.Cities.Add(city);
                            _postCantons.Add(canton);


                        }
                        continue;

                    } //Get Cities and Cantons
                    if (fields[0].Equals("04")) //Get Streets
                    {
                        if (fields.Length >= 9)
                        {
                        }
                        else
                        {
                            continue;
                        }

                        var street = new PostStreet();

                        street.STRID = long.Parse(fields[1]);

                        street.FK_ONRP = long.Parse(fields[2]);
                        street.Name = fields[4];

                        //Now search for the city.................

                        foreach (var canton in _postCantons)
                        {
                            foreach (var city in canton.Cities)
                            {
                                if (city.ONRP == street.FK_ONRP)
                                {
                                    //Match found
                                    if (city.Streets == null) city.Streets = new List<PostStreet>();
                                    city.Streets.Add(street);

                                    continue;
                                }

                            }

                        }
                    }  //Get Streets
                    if (fields[0].Equals("06"))
                    {
                        if (fields.Length > 7)
                        {
                        }
                        else
                        {
                            continue;
                        }

                        var house = new PostHouse();
                        var fkid = house.FK_STRID;
                        house.FK_STRID = long.Parse(fields[2]);
                        if (!fields[3].Equals(""))
                        {
                            house.HouseNumber = long.Parse(fields[3]);

                        }
                        if (streets == null)
                        {
                            streets = _postCantons.SelectMany(x => x.Cities)
                           .SelectMany(x => x.Streets);
                        }



                        foreach (var street in streets)
                            if (street.STRID == house.FK_STRID)
                            {
                                street.Houses.Add(house);

                            }

                        if (!printed)
                        {
                            Console.WriteLine("Collecting Houese"); printed = true;
                        }

                    } // Get Houses
                    if (fields[0].Equals("07"))
                    {
                        break;
                    }



                }
                _postSwiss = new PostSwiss();
                _postSwiss.Cantons = _postCantons;
            }

        }


        public List<PostCanton> GetCantons()
        {
            return _postCantons.ToList();
        }
        public PostSwiss GetSwiss()
        {

            return _postSwiss;
        }

        public async void UpdateCantons(PostSwiss switzerland, string path, bool onlyDiff = true, bool updateHouseNumbers = false)
        {
            


        }
    }
}


    

