﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwissPostAddressReader
{
    public class PostSwiss
    {
        public List<PostCanton> Cantons { get; set; }
    }
}
