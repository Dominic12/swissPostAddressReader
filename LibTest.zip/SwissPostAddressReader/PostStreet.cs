﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwissPostAddressReader
{
    public class PostStreet
    {
        public List<PostHouse> Houses { get; set; }
        public string Name { get; set; }
        public long FK_ONRP { get; set; }
        public long STRID { get; set; }
        public PostStreet()
        {
            this.Houses = new List<PostHouse>();
        }

    }
}
