﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwissPostAddressReader
{
    public class PostHouse
    {
        public long HouseNumber { get; set; }
        public long FK_STRID { get; set; }

    }
}
